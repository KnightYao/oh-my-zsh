## marked2

Plugin for Marked 2, a previewer for Markdown files on Mac OS X 

### Requirements

 * [Marked 2](http://marked2app.com)

### Usage

 * If `marked` is called without an argument, open Marked

 * If `marked` is passed a file, open it in Marked
